- pour compiler le programme lancé la commande make 
- pour exécuter le programme lancé la commande ./main "nom_dun_fichier" ( vous pouvez utiliser le fichier test.txt qui est l'automate donnée 
pour exemple sur le sujet )
